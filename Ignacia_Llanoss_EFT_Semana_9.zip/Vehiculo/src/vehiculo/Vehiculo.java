package vehiculo;

public class Vehiculo {
    
    private String patente;
    private double kilometros;
    private double litros;
    private double rendimiento;
    
     public Vehiculo(String patente, double kilometros, double litros){
    this.patente = patente;
    this.kilometros = kilometros;
    this.litros = litros;
    this.rendimiento = calcularRendimiento();      
    }
    
    public double calcularRendimiento(){
        if(litros > 0){
              return kilometros/litros;
        } else{
            return 0;
        }
    }
    public String getPatente(){
        return patente;
    }
    public double getKilometros(){
        return kilometros;
    }
    public double getLitros(){
        return litros;
    }
    public double getRendimiento(){
        return rendimiento;
    }
}