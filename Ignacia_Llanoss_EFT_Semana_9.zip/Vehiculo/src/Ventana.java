import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.io.FileWriter;
import java.io.IOException;
import vehiculo.Vehiculo;


public class Ventana extends JFrame {
    ArrayList<Vehiculo> listaVehiculos = new ArrayList<>();
    
    public Ventana(){
        setTitle("Registro de Vehiculos");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());
      
        JLabel titulo = new JLabel("Registro de Vehiculos");
        add(titulo);
        
        JLabel textoPatente = new JLabel("Patente:");
        add(textoPatente);
        
        JTextField patente = new JTextField(10);
        add(patente);
        
        JLabel textoKilometros = new JLabel("Kilometros:");
        add(textoKilometros);

        JTextField kilometros = new JTextField(10);
        add(kilometros);
        
        JLabel textoRendimiento = new JLabel("Rendimiento:");
        add(textoRendimiento);
           
        JTextField rendimiento = new JTextField(10);
        add(rendimiento);
        
        JLabel textolitros = new JLabel("Litros");
        add(textolitros);
        
        JTextField litros = new JTextField(10);
        add(litros);
        
        JButton registrar = new JButton("Registrar Vehiculo");
        add(registrar);

        registrar.addActionListener(E -> {
        
            String patenteIngresada = patente.getText();
            String kmTexto = kilometros.getText();
            String litrosTexto = litros.getText();
            
            if(patenteIngresada.isEmpty()){
                System.out.println("Debe ingresar una patente");
                return;
            }
            
            double km = Double.parseDouble(kmTexto);
            double litrosVal = Double.parseDouble(litrosTexto);
            
            double rendimientoCalculado = km / litrosVal;
            
            Vehiculo nuevo = new Vehiculo(patenteIngresada, km, litrosVal);
            listaVehiculos.add(nuevo);
         try {
      FileWriter fw = new FileWriter("vehiculos.txt", true);

    fw.write("Patente: " + patenteIngresada +
            " | Km: " + km +
            " | Litros: " + litrosVal +
            " | Rendimiento: " + rendimientoCalculado + "\n");

    fw.close();
    
    patente.setText("");
    kilometros.setText("");
    litros.setText("");
    
    JOptionPane.showMessageDialog(null, "Vehiculo registrado correctamente");

} catch (Exception ex) {
    System.out.println("Error al guardar en TXT");
}
            
        System.out.println("Boton funcionando");
        System.out.println("Patente: " + patenteIngresada);
        System.out.println("Rendimiento: " + rendimientoCalculado);
});
        setVisible(true);
    }
    
    }